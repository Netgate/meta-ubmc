/* nrdm

   nrdm is a web services dispatcher. It's job is to make web service calls as requested by other system components,
   and to provide the responses.
   The program makes use of several web services internally:
      * HeartBeat tells us that the server is available, and presents a 16 bit flag telling us if it needs anything
      * TimeOfDay tells us the time so that we can set our clock if required.
      * ShellCmd gets commands from the server, executes them and posts the response back to the server
      * ReqConfig gt=ets any configuration values from the server
      * SendLog aends compressed syslog files
      * Alert sends text messages to the server

   nrdm is normally run as a daemon by using the add-daemon script. eg: "add-daemon webservices /usr/sbin/wsd" but
   you can also do something like if ( ! pgrep wsd ) ; then wsd &; fi


   5/3/2013 - Send SOAP faults to error file instead of stderr
*/

#include <time.h>
#include <sys/time.h>
#include <syslog.h>
#include <stdio.h>
#include <stdarg.h>
#include <syslog.h>
#include <signal.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include "soapH.h"
#include "nrdmPortBinding.nsmap"
#include "soapStub.h"

#define TRUE 1
#define FALSE 0

#define PLATFORM "micro-BMC"
//#define LOGS

// HeartBeat flag definitions
#define MGMT_REQ      (1 << 0)
#define NEW_FW_RDY    (1 << 1)    // new firmware ready for download
#define ROLL_CALL     (1 << 2)    // send me a Navigator DH packet right now
#define CONFIG_AVAIL  (1 << 3)    // A new config is available
#define TUNNEL_REQ    (1 << 4)    // Start a new tunnel as defined in config vpnclient2
#define WAP_SCAN_REQ  (1 << 5)    // Do a wireless scan and send the results using Alert()
#define NWK_SCAN_REQ  (1 << 6)    // Set up a VPN so we can scan the LAN down it using Nessus etc
#define TBD07         (1 << 7)
#define TBD08         (1 << 8)
#define TBD09         (1 << 9)
#define TBD10         (1 << 10)
#define TBD11         (1 << 11)
#define TBD12         (1 << 12)
#define TBD13         (1 << 13)
#define TBD14         (1 << 14)
#define REBOOT        (1 << 15) 


#define CLOSE_ENOUGH 5
#define MAX_URL_LEN 128
#define SEC_1 1000000
// Invoke the TimeOfDay service every this many seconds
#define TOD_INTERVAL 86400
// Invoke the HeartBeat    "      "     "    "     "
#define HB_INTERVAL     60  
#define WITH_LINE_NUM  1
#define NO_LINE_NUM    0
#define RESP_BFR_SZ  (32*1024)
#define SOAP_TIMEOUT   20   // Give up after this many seconds. Needs to be no larger than HB_INTERVAL
#define SOAP_SSL_MODE SOAP_SSL_REQUIRE_SERVER_AUTHENTICATION | SOAP_SSL_SKIP_HOST_CHECK|SOAP_SSL_ALLOW_EXPIRED_CERTIFICATE
#define DFLT_ENDPOINT "ndrm.netgate.com"
#define DFLT_CERTPATH "/etc/netgate.pem"
#define DFLT_SSLPWD   "scrivner"
#define NO_SSL   0
//----------------------------------------------------------------------------------------------------
// Prototypes
//----------------------------------------------------------------------------------------------------
int  TimeOfDay(int);
int  ws_TimeOfDay(char *, int);
int  HeartBeat(int);
int  ws_HeartBeat(unsigned int *, int);
int  ShellCmd(int);
int  ws_ShellCmd(char *, char *, int);
int  Alert(int);
int  ws_Alert(char *, char *, int);
int  SendLog(int);
int  ws_SendLog(char *message, char *md5, int SSL);
int  ConfigReq(int);
int  ws_ConfigReq(int SSL);
int  GetSystemCall(const char *, char *, size_t);
int  Initialize(void);
int  DisplayLog(int, char *, ...);
int  read_options(int, char **);
void soap_renew(void);
void quit(int);
void sigpipe_handler(int);
void init_ssl(void);
void free_context(void);
void init_context(int);
int  nvram_write(char *);
void save_time(time_t);

//---------------------------------------------------------------------------------------------------
// Globals
//---------------------------------------------------------------------------------------------------
char version[] = {"0.10"};
char ResponseBuffer[RESP_BFR_SZ];
char TimeString[60];
char ShellString[256];
int  Verbose = FALSE;
int  Debug = FALSE;
char WS_Endpoint[256];
char WS_CertPath[256];
char SSL_Pwd[64];
int  Pilot2 = FALSE;
char MACAddrStr[20] = {"00:52:7a:7f:ff:ff"};
int  SvrBfr = 0;	   // Number of characters at a time the server will accept
int  RmtMgmt = FALSE;
time_t epoch, last_HB = 0, last_TOD = 0;
int  ContextReady = FALSE;
int  EVDOReady = FALSE;
int  EVDORunning = FALSE;
int  HB_Interval = HB_INTERVAL;
const char *dir_path = "/tmp/alerts";  // Where alert messages are left for us to pick up and send
char filepath[256];
unsigned int prevHB = 0;
int  WithSSL = 1;
int  TimeOnly = FALSE;
int  TimeLimitAvail = FALSE;
struct soap soap;
int  MACSpoof = FALSE;
FILE *DbgFile;
char DbgFileName[] = {"/tmp/wsd.err"};
//---------------------------------------------------------------------------------------------------

int main(char argc, char **argv)
{
   unsigned long sleep_time;

   // Get the command line options
   read_options(argc, argv);

   DisplayLog(NO_LINE_NUM, "Netgate Remote Device Management damon ver %s started.\n\n", version);

   Initialize();

   Debug = TRUE;

   soap.connect_timeout = SOAP_TIMEOUT;

   // Be receptive to terminate signals
   signal(SIGTERM, quit);
   // and SIGPIPE signals - This is REQUIRED when using openssl
   signal(SIGPIPE, sigpipe_handler);

   // Just check we can get the time of day, then quit. This is used by external programs
   // to verify connectivity to the RMS
   if(TimeOnly)
      {
      if(!TimeOfDay(NO_SSL))
         {
         DisplayLog(WITH_LINE_NUM, "TimeOfDay service failed!\n");
         quit(1);
         }
      else
         {
         DisplayLog(WITH_LINE_NUM, "TimeOfDay service succeeded\n");
         quit(0);
         }
      }

   // In Debug mode, we need a file handle for the SOAP handler to write errors to
   if(Debug)
      {
      DbgFile = fopen(DbgFileName, "a+");
      if(DbgFile == NULL)
         printf("Error opening debug file\n");

      fwrite("gSOAP error log started\n", 1, 24, DbgFile);
      fflush(DbgFile);
      }

   for(;;)
      {
      time(&epoch);

      // Time for a HeartBeat?
      if(abs(difftime(epoch, last_HB)) >= HB_Interval)
         {
         last_HB = epoch;
         save_time(epoch);

         // Invoke the heartbeat service to tell the system we are here 
         // and to see if it wants anything
         if(!HeartBeat(NO_SSL))
            DisplayLog(WITH_LINE_NUM, "HeartBeat service failed!\n");

         if(!Alert(NO_SSL))
            DisplayLog(WITH_LINE_NUM, "Alert service failed!\n");
         }
      else if(RmtMgmt)
         {
         if(!HeartBeat(NO_SSL))
            DisplayLog(WITH_LINE_NUM, "HeartBeat service failed!\n"); 
         }

      // The TimeOfDay we can check less frequently
      if((abs(difftime(epoch, last_TOD)) >= TOD_INTERVAL) || (epoch < 1280000000))
         {
         last_TOD = epoch;

         if(!TimeOfDay(NO_SSL))
            {
            DisplayLog(WITH_LINE_NUM, "TimeOfDay service failed!\n");
            usleep(SEC_1);
            }
         }

      // If we are in MGMT mode, we poll the server every second
      if(RmtMgmt)
         {
         if(!ShellCmd(WithSSL))
            DisplayLog(WITH_LINE_NUM, "ShellCmd service failed\n");
         }
      usleep(SEC_1);	// sleep for about a second.
      } // e-o-for(;;)

    quit(0);
}

//-----------------------------------------------------------------------------------------------
// Read any system/config stuff we need and set our global vars
//-----------------------------------------------------------------------------------------------
int Initialize(void)
{
   DisplayLog(NO_LINE_NUM, "Platform:    %s\n", PLATFORM);

   HB_Interval = HB_INTERVAL;

   // Is timelimit utility available?
   if(system("[ -e /usr/sbin/timelimit ]") == 0)
       TimeLimitAvail = TRUE;
    
   GetSystemCall("ifconfig|grep eth0|awk '{print $5}'|tr : -", MACAddrStr, 18);

   DisplayLog(NO_LINE_NUM, "MAC Address: %s\n", MACAddrStr);
   strcpy(SSL_Pwd, DFLT_SSLPWD);

      strcpy(WS_Endpoint, DFLT_ENDPOINT);

   DisplayLog(NO_LINE_NUM, "WS_Endpoint: %s\n", WS_Endpoint);
   strcpy(WS_CertPath, DFLT_CERTPATH);
   DisplayLog(NO_LINE_NUM, "WS_CertPath: %s\n", WS_CertPath);

   if(Debug)
      DisplayLog(NO_LINE_NUM, "Debug:       On\n");

   if(!WithSSL)
      DisplayLog(NO_LINE_NUM, "SSL:         Disabled\n");
   else
      DisplayLog(NO_LINE_NUM, "SSL:         Enabled\n");

   if(TimeLimitAvail)
       DisplayLog(NO_LINE_NUM, "Timelimit:   Available\n");
   else
       DisplayLog(NO_LINE_NUM, "Timelimit:   Not available\n");
    
   if(Verbose)
      printf("------------------------------------------------------------------\n");

   // Make sure the directory from which we read alert messages exists (Lesson in non-portable coding)
   sprintf(ShellString, "if [ ! -d %s ] ; then mkdir %s; fi", dir_path, dir_path);
   system(ShellString);
   system("echo -e \"Power up\nmicro-BMC powered up\" >/tmp/alerts/powerup.alrt");

}

//---------------------------------------------------------------------------
// DisplayLog
// Send string to the syslog, and to stdout if the verbose flag is set.
//---------------------------------------------------------------------------
#define MAXLOGLEN 512
int DisplayLog(int num, char *pFmt, ...)
{
   static int  msgcount = 0;
   int RetVal = 0;
   char *logstr;
   char *p;

   logstr = malloc(MAXLOGLEN);

   va_list Marker;
   va_start(Marker, pFmt);
   RetVal = vsnprintf(logstr, MAXLOGLEN-1, pFmt, Marker);
   va_end(Marker);

   // Limit the log message to one line
   if((p = strchr(logstr, '\n')) != NULL)
      *(p+1) = '\0';

   syslog(LOG_DAEMON|LOG_INFO, "wsd: %s", logstr);

   if(Verbose)
      {
      if(num)
         printf("%06d: ", msgcount++);

      fputs(logstr, stdout);
      }

   free(logstr);
   return RetVal;
}

// Read the command line options and set the program variables as required
// Returns idx of the first non-option on the command line
int read_options(int argc, char **argv)
{
   int c;
   int args = 0;
   extern char *optarg;
   extern int optind, opterr, optopt;

   while ((c = getopt(argc, argv, "dhsvtVm:")) != -1)
      {
      args++;

      switch (c)
         {
         // Specify the MAC address
         case 'm':
            strcpy(MACAddrStr, optarg);
            MACSpoof = TRUE;
            break;
         // Debug
         case 'd':
            Debug = TRUE;
            break;
         // Time of day only
         case 't' :
            TimeOnly = TRUE;
            break;

         // SSL
         case 's':
            WithSSL = 0;
            break;
         // Verbose
         case 'v':
            Verbose = TRUE;
            break;
         // Version
         case 'V':
            printf("wsd %s\n", version);
            exit(0);
            break;
         // Help
         case 'h':
            printf("wsd: Web Service Daemon\n");
            printf("  -t Get the time of day and quit\n");
            printf("  -s Don't use SSL\n");
            printf("  -v Verbose\n");
            printf("  -d Debug\n");
            printf("  -V Print version and exit\n");
            printf("  -m <MAC Address> Use MAC address provided instead of host's MAC\n");
            exit(0);
         }
      }

   return(optind);
}

void quit(int sig)
{
   if(sig > 1 )
      DisplayLog(WITH_LINE_NUM, "Terminated by signal %d\n", sig);
   soap_destroy(&soap);
   soap_end(&soap);
   soap_done(&soap);

   if(Debug)
      fclose(DbgFile);
      
   exit(sig);
}

void init_ssl(void)
{
   if(soap_ssl_client_context(&soap, SOAP_SSL_MODE, WS_CertPath, SSL_Pwd, "/etc/cacert.pem", NULL, NULL))
      {
      if(Debug)
         soap_print_fault (&soap, stderr);

      DisplayLog(WITH_LINE_NUM, "SSL Initializtion error\n");
      }

}

void sigpipe_handler(int x)
{
   DisplayLog(WITH_LINE_NUM, "SIGPIPE event (0x%02x) received\n", x);
}

// Free our soap structure
void free_context(void)
{
   if(!ContextReady)
      return;

   soap_destroy(&soap);
   soap_end(&soap);
   soap_done(&soap);
   ContextReady = FALSE;
}

// Init our soap structure
void init_context(int SSL)
{
   if(ContextReady)
      return;

   if(SSL)
      soap_ssl_init();

   soap_init(&soap);
   soap.connect_timeout = 20;
   if(SSL)
      init_ssl();

   ContextReady = TRUE;
}

// Save the current epoch time in a file in tmp. This may be used by an external watchdog to make sure
// wsd is running properly.
void save_time(time_t cur_epoch)
{
   FILE *wdfile;

   if((wdfile = fopen("/tmp/last_heartbeat", "w")) != NULL)
      {
      fprintf(wdfile, "%10.10u\n", (unsigned int)cur_epoch);  
      fclose(wdfile);
      }
      
}

//---------------------------------------------------------------------------------------------------
// Each web service we call has it's own file, included here.(Makes the #includes simpler)
// Usually there is a wrapper function using the name of the service such as Alert(), and a function
// that calls the web service, named ws_service_name, such as ws_Alert()
//---------------------------------------------------------------------------------------------------
#include "alert.c"
#include "shell.c"
#include "timeofday.c"
#include "heartbeat.c"
#include "configreq.c"
