//-----------------------------------------------------------------------------------------------
// Interpret the flags returned by the heartbeat web service and act accordingly
// Return TRUE if the web service succeeded
//-----------------------------------------------------------------------------------------------
int HeartBeat(int SSL)
{
   unsigned int HBResp;
   int rv;

   init_context(SSL);

   if(ws_HeartBeat(&HBResp, SSL))
      {
      if(Debug)
         DisplayLog(WITH_LINE_NUM, "Heartbeat flag value = 0x%08x\n", HBResp); 

      // Server requesting a reboot?
      if((HBResp == REBOOT) && (prevHB != REBOOT))
         {
         sprintf(ShellString, "echo -n \"wsd reboot (%04x) at \" >>/mnt/SmartMedia/wsd.log", HBResp);
         system(ShellString);
         system("date >>/mnt/SmartMedia/wsd.log");
//         system("reboot");	
         }

      // Are there configurations waiting for this device?
      if(HBResp & CONFIG_AVAIL)
         {
         if(!ConfigReq(NO_SSL))
            DisplayLog(WITH_LINE_NUM, "ConfigReq service failed!\n");
         }

#ifndef PILOT
      // Should we act on a new network scan request?
      if(HBResp & NWK_SCAN_REQ)
         {
         if(~prevHB & NWK_SCAN_REQ)
            system("service vpnclient2 start");
         }
      else
         {
         if(prevHB & NWK_SCAN_REQ)
            system("service vpnclient2 stop");
         }

      // Need to do a WAP scan. We will compose a shell script and execute it
      if((HBResp & WAP_SCAN_REQ) && (~prevHB & WAP_SCAN_REQ))
         {
         sprintf(ShellString, "echo -e \""
                "if ( pgrep httpd ) ; then\n"
                "   ADMIN=true\n"
                "   service admin stop\n"
                "else\n"
                "   ADMIN=false\n"
                "fi\n"
                "\n"
                "httpd -s\n"
                "wlprint /tmp/scan.dat >/tmp/alerts/wapscan.res\n"
                "if ( %c$ADMIN ) ; then\n"
                "   service admin start\n"
                "fi\n"
                "\""
                " >/tmp/scan.sh", '\\');

         system(ShellString);
         system("/bin/ash /tmp/scan.sh");
         }
#endif

      // Server requesting a shell session? 
      if(HBResp & MGMT_REQ)
         {
         SvrBfr = (int)((HBResp >> 16) & 0x0000ffff);
         if(!RmtMgmt)
            DisplayLog(WITH_LINE_NUM, "Svr requested new mgmt session, buf sz = %d\n", SvrBfr);

         RmtMgmt = TRUE;
         }
      else
         {
         if(RmtMgmt)
            {
            DisplayLog(WITH_LINE_NUM, "Server has terminated the mgmt session\n");
            RmtMgmt = FALSE;
            }
         }

      prevHB = HBResp;	// Record the the heartbeat value to we can detect if it changes
      rv = TRUE;
      }
   else
      rv = FALSE;

   free_context();
   return(rv);
}

//-----------------------------------------------------------------------------------------------
// Use gSOAP to invoke the HeartBeat web servie
// Return TRUE if the web service succeeded
//-----------------------------------------------------------------------------------------------
int ws_HeartBeat(unsigned int *resp, int SSL) 
{
    int rv;
    struct ns1__HeartBeat *HB;
    struct ns1__HeartBeatResponse *result;
    char Endpoint[256];

    HB = malloc(sizeof(struct ns1__HeartBeat));
    result = malloc(sizeof(struct ns1__HeartBeatResponse));

    HB->MacAddress = MACAddrStr;

    if(SSL)
       strcpy(Endpoint, "https://");
    else
       strcpy(Endpoint, "http://");

    strcat(Endpoint, WS_Endpoint);

    if(soap_call___ns1__HeartBeat(&soap, Endpoint, NULL, HB, result) == SOAP_OK)
        {
        *resp = (unsigned int)(result->return_);

        // Sanity check the return value
        if(*resp == 0xffffffff)
           {
           *resp = 0;
           rv = FALSE;
           }
        else
           rv = TRUE;
        }
    else
        {
        *resp = 0;
        rv = FALSE;
        if(Debug)
           {
           soap_print_fault(&soap, DbgFile);
           fflush(DbgFile);
           }
        }

    free(HB);
    free(result);

    return rv;
}
