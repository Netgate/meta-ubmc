#define MAXCONFIGITEMSIZE 8092

char **ConfigStrings;
int  ConfigsAvail = 0;

//-----------------------------------------------------------------------------------------------received
// Retrieve any configuration items that are waiting for us.
// We recognize certain config items as requiring a service restart
//-----------------------------------------------------------------------------------------------
int ConfigReq(int SSL)
{
   int rv;
   int idx;
   int  RestartVPN1, RestartRadio, RestartSystem;

   DisplayLog(WITH_LINE_NUM, "Checking for configuration update\n");

   // Do the web services thing
   init_context(SSL);

   // Invoke the web service, which should set ConfigStrings to point to an array of "key=value" strings
   if(ws_ConfigReq(SSL))
      {
      RestartVPN1 = FALSE;
      RestartRadio = FALSE;
      RestartSystem = FALSE;

      for(idx=0;idx<ConfigsAvail;idx++)
         {
         if(Debug)
            DisplayLog(WITH_LINE_NUM, "Received config: %s\n", ConfigStrings[idx]);

         // Save the configs, and restart any services affected
         if((strlen(ConfigStrings[idx]) >= MAXCONFIGITEMSIZE) || (strchr(ConfigStrings[idx], '=') == NULL))
            DisplayLog(WITH_LINE_NUM, "Error: Config item invalid or too large!\n");
         // If we should restart the system after the config change, set a flag
         else if(strncmp(ConfigStrings[idx], "auto_reboot=yes", 15) == 0)
               RestartSystem = TRUE;
	       else
            {
            if(!Debug)
               nvram_write(ConfigStrings[idx]);

            // If the config key changes anything in the vpn1 setup, restart the tunnel when we are done
            if(strncmp(ConfigStrings[idx], "vpn_client1", 11) == 0)
               RestartVPN1 = TRUE;

            // If the config key changes anything in the radio setup, restart it when we are done
            if(strncmp(ConfigStrings[idx], "wl0_", 4) == 0)
               RestartRadio = TRUE;
            }
         } // e-o-for-idx<ConfigsAvail

      if(Debug)
         DisplayLog(WITH_LINE_NUM, "(Not really) committing new configuration items\n");
      else
         {
         DisplayLog(WITH_LINE_NUM, "Committing new configuration items\n");
         system("setconf config_status NEW");
         }


      if(RestartVPN1)
         {
         if(Debug)
            DisplayLog(WITH_LINE_NUM, "Restarting VPN_1\n");
         else
            system("service vpnclient1 restart");
         }

      if(RestartRadio)
         {
         if(Debug)
            DisplayLog(WITH_LINE_NUM, "Restarting Radio\n");
         else
            {
            system("rc radio stop");
            usleep(SEC_1);
            system("rc radio st");
            }
         }


      system("echo -e \"wsd\nConfiguration updated\" >/tmp/alerts/config.alrt");

      if(RestartSystem)
         {
         if(Debug)
            DisplayLog(WITH_LINE_NUM, "(Not really) rebooting\n");
         else
            {
            Alert(NO_SSL);
            usleep(4000000);
            system("reboot");
            }
         }

      rv = TRUE;
      }
   else
      rv = FALSE;

   free_context();

   if(Debug && MACSpoof)
      quit(0);

   return(rv);
}

//-----------------------------------------------------------------------------------------------
// Use gSOAP to invoke the ReqConfig web service
// Return TRUE if the web service succeeded
// We should get an array of strings each of the form key=value
//-----------------------------------------------------------------------------------------------
int ws_ConfigReq(int SSL) 
{
    int rv;
    struct ns1__ReqConfig *CFG;
    struct ns1__ReqConfigResponse *result;
    char Endpoint[256];

    CFG = malloc(sizeof(struct ns1__ReqConfig));
    result = malloc(sizeof(struct ns1__ReqConfigResponse));

    CFG->MacAddress = MACAddrStr;

    if(SSL)
       strcpy(Endpoint, "https://");
    else
       strcpy(Endpoint, "http://");

    strcat(Endpoint, WS_Endpoint);

    if(soap_call___ns1__ReqConfig(&soap, Endpoint, NULL, CFG, result) == SOAP_OK)
       {
       rv = TRUE;
       ConfigStrings = result->return_;
       ConfigsAvail = result->__sizereturn_ -1;
       }
    else
        {
        rv = FALSE;
        if(Debug)
           {
           soap_print_fault(&soap, DbgFile);
           fflush(DbgFile);
           }
        }

    free(CFG);
    free(result);
    return rv;
}

int nvram_write(char *s)
{
   char *dst, *cfg;
   int  first_equal;


   //Replace the first '=' with space-quote and put another quote at the end
   dst = strchr(s, '=');
   cfg = s;
   
   if(dst == NULL)
      {
      DisplayLog(WITH_LINE_NUM, "Invalid config string. No \"=\"\n");
      return(FALSE);
      }
      
   *dst = '\0';

   sprintf(ShellString, "setconf %s", s);
   strcat(ShellString, " \"");
   strcat(ShellString, ++dst);
   strcat(ShellString, "\"");
   system(ShellString);

   return TRUE;
}
