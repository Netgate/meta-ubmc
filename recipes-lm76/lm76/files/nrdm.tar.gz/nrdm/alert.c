#define MAXALERTSZ (1024*20)

//-----------------------------------------------------------------------------------------------
// Look in the directory /tmp/alerts for any files. If we find one, parse it into alert and message
// components (first line, and the rest) and feed it to the ws_Alert() to be sent to the host 
// Return FALSE if we tried a web service call and it failed
//-----------------------------------------------------------------------------------------------
int Alert(int SSL)
{
   int rv;
   struct dirent *dp;
   struct stat st;
   size_t filesize;
   char *mp;
   char *gp;
   int  idx;

   rv = TRUE;
   dir_path = "/tmp/alerts";

   DIR *dir = opendir(dir_path);

   // List the files in the alerts directory
   while((dp = readdir(dir)) != NULL)
      {
      // cat the path and filename
      sprintf(filepath, "%s/%s", dir_path, dp->d_name);
      if(dp->d_name[0] != '.')
         {
         // See how big this file is so we can reserve some memory for it
         mp = NULL;
         stat(filepath, &st);
         filesize = st.st_size;

         if(filesize < MAXALERTSZ)
            {
            if((mp = (char *)malloc(filesize+2)) != NULL)
               {
               // Read the file into memory
               sprintf(ShellString, "cat %s", filepath);
               GetSystemCall(ShellString, mp, filesize);

               // point to the start of the file we just read into memory
               gp = mp;
               idx = 0;
               // Locate the firsr EOL
               while((*gp != '\n') && (idx++ < (filesize)))
                  gp++;

               if(idx < filesize)
                  {
                  *gp++ = '\0';	// replace the first EOL with a null to split the string into two

                   // Do the web ervices thing
                   init_context(SSL);

                   if(ws_Alert(mp, gp, SSL))
                      {
                      DisplayLog(WITH_LINE_NUM, "Alert msg: \"%s\", payload: \"%s\" sent\n", mp, gp);
                      unlink(filepath);
                      }
                   else
                      rv = FALSE;

                   free_context();
                  }
               else
                  DisplayLog(WITH_LINE_NUM, "Bogus alert file: %s\n", filepath);

               free(mp);
               }
            }
         }
      }

   closedir(dir);
   return(rv);
}

//-----------------------------------------------------------------------------------------------
// Use gSOAP to invoke the Alert web service
// Return TRUE if the web service succeeded
//-----------------------------------------------------------------------------------------------
int ws_Alert(char *alert, char *message, int SSL) 
{
    int rv;
    struct ns1__Alert *ALRT;
    struct ns1__AlertResponse *result;
    char Endpoint[256];

    ALRT = malloc(sizeof(struct ns1__Alert));
    result = malloc(sizeof(struct ns1__AlertResponse));

    ALRT->MacAddress = MACAddrStr;
    ALRT->AlertMsg=alert;
    ALRT->Payload=message;

    if(SSL)
       strcpy(Endpoint, "https://");
    else
       strcpy(Endpoint, "http://");

    strcat(Endpoint, WS_Endpoint);

    if(soap_call___ns1__Alert(&soap, Endpoint, NULL, ALRT, result) == SOAP_OK)
        rv = TRUE;
    else
        {
        rv = FALSE;
        if(Debug)
           {
           soap_print_fault(&soap, DbgFile);
           fflush(DbgFile);
           }
        }

    free(ALRT);
    free(result);
    return rv;
}
