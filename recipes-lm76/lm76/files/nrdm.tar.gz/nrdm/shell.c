extern int  MACSpoof;

//-----------------------------------------------------------------------------------------------
// Ask the server if it has any commands for us
// If it does, execute them and send the server the results in SvrBfr sized chunks
//-----------------------------------------------------------------------------------------------
int ShellCmd(int SSL)
{
   int  respchars, bfrchars;
   int  rv, cmdexit;
   char *response, *mp;
   int  RebootRequired = FALSE;
   int  UpdateRequired = FALSE;

   // Sanity check the server max string length, or we will be here for ever
   if((SvrBfr < 1) || (SvrBfr > RESP_BFR_SZ))
      {
      DisplayLog(WITH_LINE_NUM, "SvrBfr is insane\n");
      return FALSE;
      }

   rv = TRUE;

   response = malloc(SvrBfr + 2);
   mp = ResponseBuffer;

   init_context(SSL);

   // Check to see if the svr has a command for us to execute
   if(ws_ShellCmd(ShellString, (char *)NULL, SSL))
      {
      if(strlen(ShellString) != 0)
         {
         // if it did ...
         DisplayLog(WITH_LINE_NUM, "\"%s\" received\n", ShellString);

         if(!MACSpoof)
            {
            // Execute the command, and measure the length of the resulting output
	         // "reboot" is a special case, because all operation ceases once that is sent to the system!
            if(strncmp("reboot", ShellString, 7) == 0)
               {
               RebootRequired = TRUE;
               strcpy(ResponseBuffer, "System reboot scheduled");
               respchars = 25;
               cmdexit = 0;
               }
	         else if(strncmp("upd-firmware", ShellString, 12) == 0)
               {
               UpdateRequired = TRUE;
               strcpy(ResponseBuffer, "System update scheduled");
               respchars = 25;
               cmdexit = 0;
               }
            else
               {
               cmdexit = GetSystemCall(ShellString, ResponseBuffer, RESP_BFR_SZ);
               respchars = strlen(ResponseBuffer);
               }

            // If the command produced no output, just send a confirmation message
            if(respchars == 0)
               {
               if(cmdexit != 0)
                  sprintf(ResponseBuffer, "Command exited with %d\n", cmdexit);
               else
                  strcpy(ResponseBuffer, "Execution complete.");

               respchars = strlen(ResponseBuffer);
               }
            }
         else
            {
            strcpy(ResponseBuffer, "Not executed. We are spoofing the MAC address\n");
            respchars = strlen(ResponseBuffer);
            }
            
         // Now feed the output back to the server, SvrBfr bytes at a time until there is no more to send
         do {
            strncpy(response, mp, SvrBfr);
            response[SvrBfr] = '\0';
            bfrchars = strlen(response);
            mp += bfrchars;

            if(Debug)
               DisplayLog(WITH_LINE_NUM, "Sending %d bytes\n", bfrchars);

            if(Debug)
               usleep(1000000);

            // invoke the web service to pass command responses back to the user
            if(!ws_ShellCmd((char *)NULL, response, SSL))
               {
               DisplayLog(WITH_LINE_NUM, "Failed to put response\n");
               rv = FALSE;
               break;
               }
            } while (bfrchars == SvrBfr); // we sent the maximum string length the svr can handle

         if(rv)
            DisplayLog(WITH_LINE_NUM, "Response complete\n");
 
         if(RebootRequired)
            {
            usleep(10000000);
            system("reboot");
            }

         if(UpdateRequired)
            {
            usleep(10000000);
            system("upd-firmware");
            }
         }
      }
   else
      rv = FALSE;

   free(response);
   free_context();
   return rv;

}

//-----------------------------------------------------------------------------------------------
// Use gSOAP to invoke the ShellCmd web service
// Return TRUE if the web service succeeded
// if cmdstr == NULL, we are sending a response to the server
// if respstr == NULL, we are asking it for the next command to excute
//-----------------------------------------------------------------------------------------------
int ws_ShellCmd(char *cmdstr, char *respstr, int SSL) 
{
   int rv;
   struct ns1__ShellCmd *CMD;
   struct ns1__ShellCmdResponse *result;
   char Endpoint[256];

   CMD = malloc(sizeof(struct ns1__ShellCmd));
   result = malloc(sizeof(struct ns1__ShellCmdResponse));

   CMD->MacAddress = MACAddrStr;
   CMD->response = (char *)respstr;

   if(SSL)
      strcpy(Endpoint, "https://");
   else
      strcpy(Endpoint, "http://");

   strcat(Endpoint, WS_Endpoint);

   if(soap_call___ns1__ShellCmd(&soap, Endpoint, NULL, CMD, result) == SOAP_OK)
      {
      if(cmdstr)    // We are fetching the next command to execute
         {
         if(result->return_)
            {
            strncpy(cmdstr, result->return_, sizeof(ShellString) -1); //soap_call___ns1__ShellCmd
            cmdstr[sizeof(ShellString) -1] = '\0';
            }
         else
            strcpy(cmdstr, "");
         }
      rv = TRUE;
      }
   else
      {
      rv = FALSE;
      if(Debug)
         {
         soap_print_fault(&soap, DbgFile);
         fflush(DbgFile);
         }
      }

   free(CMD);
   free(result);

   return rv;
}
