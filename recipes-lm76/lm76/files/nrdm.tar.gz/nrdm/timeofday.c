//-----------------------------------------------------------------------------------------------
// Interpret the time string returned by the TimeOfDay web service, and set the system clock & RTC
// if they don't agree
// Rerutn TRUE if the web service succeeded
//-----------------------------------------------------------------------------------------------
int TimeOfDay(int SSL)
{
   time_t lt;
   time_t delta;
   struct timeval syst;
   struct timezone tz;
   int rv;

   init_context(SSL);

   if(ws_TimeOfDay(TimeString, SSL))
      {
      DisplayLog(WITH_LINE_NUM, "Current server time is about: %s\n", TimeString);

      // get the current time and see how far adrift we are
      time(&lt);
      delta = abs( (int)((unsigned int)lt - (unsigned int)atoi(TimeString)) );

      // If our clock is not close enough to the system time, set it.
      if(delta > CLOSE_ENOUGH)
         {
         DisplayLog(WITH_LINE_NUM, "%s clock is %d seconds out. Setting system time\n", PLATFORM, delta);

         syst.tv_sec = (time_t)atoi(TimeString);
         syst.tv_usec = 0;
         tz.tz_minuteswest = 0;
         settimeofday(&syst, &tz);
         
#ifdef PILOT
         if(Pilot2)
            system("hwclock -w");
         else
            system("rtcp -c");
#endif
         // Mke sure our timers are based on the new value, or things will get confusing
         time(&epoch);
         last_HB = last_TOD = epoch;
         }
      rv = TRUE;
      }
   else
      rv = FALSE;

   free_context();
   return(rv);

}

//-----------------------------------------------------------------------------------------------
// Use gSOAP to invoke the TimeOfDay web servie
// Return TRUE if the web service succeeded
//-----------------------------------------------------------------------------------------------
int ws_TimeOfDay(char *ts, int SSL) 
{
    int rv;
    struct ns1__TimeOfDay *TOD;
    struct ns1__TimeOfDayResponse *result;
    char Endpoint[256];

    TOD = malloc(sizeof(struct ns1__TimeOfDay));
    result = malloc(sizeof(struct ns1__TimeOfDayResponse));

    TOD->MacAddress = MACAddrStr;

    if(SSL)
       strcpy(Endpoint, "https://");
    else
       strcpy(Endpoint, "http://");

    strcat(Endpoint, WS_Endpoint);
 
    if(soap_call___ns1__TimeOfDay(&soap, Endpoint, NULL, TOD, result) == SOAP_OK)
        {
        strncpy(ts, result->return_, sizeof(TimeString) -1);
        rv = TRUE;
        }
    else
        {
        rv = FALSE;
        if(Debug)
           {
           soap_print_fault(&soap, stderr);
           fflush(DbgFile);
           }
        }

     free(TOD);
     free(result);

    return rv;
}
