//---------------------------------------------------------------------------
//                                   ETSec
//
//                             1000 Briggs Road
//                                Suite 120
//                       Mt. Laurel, New Jersey 08054
//
//                           Copyright 2009 ETSec
//---------------------------------------------------------------------------
//
// NAME:           SysCall.c
//
// ENGINEER:       David Gaines
//                 Doug Hudson
//
// CREATION DATE:  March 2009
//
// PURPOSE:
//
//---------------------------------------------------------------------------
// Revision History
// Version  Initials  Date     Description
// 1.0.0    DKH       20090323 Created
// 1.0.1    SJB       20100805 Trim now removes all chars < 0x0a. The 0x04 produced by
//                             dhp was causing us grief
// 1.0.2    SJB       20100816 SOAP hates Esc characters, so we now nix them
// 1.0.3    SJB       20110927 Added "timelimit" wrapper around system call
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Includes
//---------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <signal.h>
//---------------------------------------------------------------------------
// Local Includes
//---------------------------------------------------------------------------
#define _OWNER_
#include "SysCall.h"
#undef _OWNER_

#define TRUE 1
#define FALSE 0

#define WITH_LINE_NUM  1
#define NO_LINE_NUM    0
//---------------------------------------------------------------------------
// Defines
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Module scope variables
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// Public function prototypes
//---------------------------------------------------------------------------
int GetSystemCall(const char *pSystemCall, char *pResult, size_t ResultSize);
void pTimeout(int);
int GetSystemCall_X(const char *pSystemCall, char *pResult, size_t ResultSize);
int  DisplayLog(int, char *, ...);
//---------------------------------------------------------------------------
// Private function prototypes
//---------------------------------------------------------------------------
void Trim(char *Text);

extern int Debug;
extern int TimeLimitAvail;
/*------------------------------------------------------------------------------
 * Function: GetSystemCall
 * Author:   David Gaines
 * Date:     March 14, 2006
 *           March 23, 2009 by dkh
 *
 * Purpose:  Gets the text from a system call.
 *           useful for doing simple things such as getting the
 *           value for system("getconf Product_Code")
 * Parameters: pSystemCall -- The exact system call to make.
 *                           ex: getconf Product_Code
 *             pResult -- The result, ex: 603110
 *             ResultSize -- size of result buffer
 * Returns:  TRUE -- The call was successful, or FALSE.
 *------------------------------------------------------------------------------
 */
int GetSystemCall(const char *pSystemCall, char *pResult, size_t ResultSize)
{
   FILE         *pStream;
   int           c;
   unsigned int  i;
   int           RetVal = SYS_CALL_ERROR;
   char          cmdptr[256];

   // Validate parameters
   if ((pSystemCall == NULL) || (pResult == NULL) || (ResultSize < 1))
     return (SYS_CALL_ERROR);

   strcpy(cmdptr, "");

   if(strncmp(pSystemCall, "--no-timelimit", 14) == 0) 
      pSystemCall += 15;

   if(strstr(pSystemCall, "upd-firmware") == NULL)
      // precede the user's command with "timelimit -t 120" just in case
      {
      if(TimeLimitAvail)
         strcpy(cmdptr, "/usr/sbin/timelimit -t 300 ");
      }

   strcat(cmdptr, pSystemCall);

   // Initialization
   memset(pResult, 0, ResultSize);
   i = 0;

   // Try to open pipe stream
   if((pStream = popen(cmdptr, "r")) != NULL)
      {
      do
         {
         // Get the result
         c = fgetc(pStream);
         if (c != EOF)
            {
            pResult[i] = (char)c;
            i++;
            }
         }

      while ((c != EOF) && (i < (ResultSize - 1)));

      // Close the stream
      RetVal = pclose(pStream);
      // Clean up the result stream
      Trim(pResult);
      }

   return (RetVal);
}

/*------------------------------------------------------------------------------
 * Function: Trim()
 * Date:     May 5, 2005
 * Author:   David Gaines
 * Purpose:  Trims the white space (lf, cr, spaces, tabs) from the beginning
 *           and end of text.
 * Parameters: Text - the string to be trimmed.
 * Returns:  None
 *----------------------------------------------------------------------------*/
void Trim(char *Text)
{
  int i;
  int j;
  char *s;

   // Validate parameter
   if (Text == NULL)
      return;

   i = 0;

   //First figure out the number of spaces at the beginning
   while (isspace(Text[i]) != 0)
      {
      // If the entire string is spaces then set it "" and return
      if (Text[i] == '\0')
         {
         Text[0] = '\0';
         return;
         }
      i++;
      }

   // Then copy the data after the last space backwards to the beginning
   // of the string. So "  back" becomes "b back" then "baback" then
   // "bacack" then "backck" then finally "back"
   if (i > 0)
      {
      j = 0;
      do
         {
         Text[j] = Text[i];
         if (Text[i] != '\0')
            i++;

         j++;
         } while (Text[i] != '\0');

      Text[j] = '\0';
      }

  // Trimming the end is easy. While the last character is space, set it null
   while (strlen(Text) > 0)
      {
      if ((isspace(Text[strlen(Text) - 1]) != 0) || (Text[strlen(Text) - 1] < 0x0a))
         Text[strlen(Text) - 1] = '\0';
      else
         break;
      }

   // Finally, we take another pass through the string and nix anything that SOAP will barf on,
   // replacing it with an _

   s = Text;
   while(*s)
      {
      if( (*s == '\x1b') || (*s < 0x0a) )
         *s = '_';

      s++;
      }
 
}


#ifdef EXPERIMENTAL
/*------------------------------------------------------------------------------
 * Function: GetSystemCall
 * Author:   SJB
 * Date:     Sept 2010 - re-written using fork/dup2/select to facilitate time-out
 *
 * Purpose:  Gets the text from a system call.
 *           useful for doing simple things such as getting the
 *           value for system("getconf Product_Code")
 * Parameters: pSystemCall -- The exact system call to make.
 *                           ex: getconf Product_Code
 *             pResult -- The result, ex: 603110
 *             ResultSize -- size of result buffer
 * Returns:  TRUE -- The call was successful, or FALSE.
 *------------------------------------------------------------------------------
 */
int GetSystemCall_X(const char *pSystemCall, char *pResult, size_t ResultSize)
{
   int pfd[2]; 
   pid_t cpid;
   int n;
   fd_set set;
   struct timeval timeout;
   int written;

   if(pipe(pfd) !=0)
      {
      if(Debug)
         DisplayLog(WITH_LINE_NUM,"GetSystemCall() - Failed to create pipe");

      return FALSE;
      }

   switch(cpid = fork() )
      {
      case -1:
         if(Debug)
            DisplayLog(WITH_LINE_NUM,"GetSystemCall() - Failed to fork");

         return(FALSE);
         break;

      case 0:
         if(dup2(pfd[1], STDOUT_FILENO) ==-1 )
            {
            if(Debug)
               DisplayLog(WITH_LINE_NUM,"GetSystemCall() - Fail redirecting stdout");

            return(FALSE);
            }

         close(pfd[0]);
         close(pfd[1]);

         if(execl("/bin/sh", "sh", "-c", pSystemCall, NULL)==-1)
            {
            if(Debug)
               DisplayLog(WITH_LINE_NUM,"GetSystemCall() - Child failed to execute");

            return(FALSE);
            }

         break;

      default:
         close(pfd[1]);

          // set up the select() stuff 
         FD_ZERO(&set);
         FD_SET(pfd[0], &set);
         timeout.tv_sec = 30;
         timeout.tv_usec = 0;

         written = 0;
         pResult[0] = '\0';

         while(1)
            {
            switch(select(FD_SETSIZE, &set, NULL, NULL, &timeout))
               {
               case 1: // characters available
                  if((n = read(pfd[0], &(pResult[written]), ResultSize)) <= 0)
                     {
                     pResult[written] = '\0';
                     Trim(pResult);
                     close(pfd[0]);
                     return(TRUE);
                     }

                  written += n;
                  break;

               case 0: // timed out
                  DisplayLog(WITH_LINE_NUM, "GetSystemCall() - Command timed out!\n");
                  kill(cpid, SIGKILL);
                  pResult[written] = '\0';
                  strcat(pResult, "\nCommand timed out!\n");
                  Trim(pResult);
                  close(pfd[0]);
                  return(TRUE);
                  break; 

               case -1: // something broke
//                  printf("Select error\n");
                  close(pfd[0]);
                  return(FALSE);
                  break; 
               }
            }

      }

}
#endif

